import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime
import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog
import base64
import hashlib
import hmac
import secrets
import json

# Optional strong encryption (Fernet) if cryptography is installed
try:
    from cryptography.fernet import Fernet
    CRYPTO_AVAILABLE = True
except Exception:
    CRYPTO_AVAILABLE = False

# ---------------------------
# Configurações / Inicialização
# ---------------------------
SERVER_SIDE_SECRET = b"my_server_side_static_secret_change_me"  # use um valor forte em produção

try:
    cred = credentials.Certificate("serviceAccountKey.json")
    firebase_admin.initialize_app(cred)
    db = firestore.client()
except Exception as e:
    messagebox.showerror("Erro Firebase", f"Erro ao inicializar Firebase:\n{e}")
    raise SystemExit(1)

# ---------------------------
# Helpers Criptografia / Hash
# ---------------------------
def hash_password(password: str, salt: bytes = None):
    """Gera salt e hash usando PBKDF2-HMAC-SHA256."""
    if salt is None:
        salt = secrets.token_bytes(16)
    pwd_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 200_000, dklen=32)
    return salt.hex(), pwd_hash.hex()

def verify_password(password: str, salt_hex: str, hash_hex: str) -> bool:
    salt = bytes.fromhex(salt_hex)
    expected = bytes.fromhex(hash_hex)
    pwd_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 200_000, dklen=32)
    return hmac.compare_digest(pwd_hash, expected)

def derive_key_from_passphrase(passphrase: str, salt: bytes = None):
    """Deriva uma chave (32 bytes) baseada em passphrase usando PBKDF2."""
    if salt is None:
        salt = SERVER_SIDE_SECRET[:16]
    key = hashlib.pbkdf2_hmac('sha256', passphrase.encode('utf-8'), salt, 200_000, dklen=32)
    return key

# Encriptação de mensagem: usa Fernet se disponível e se o usuário fornecer uma senha de conversa.
# Caso contrário, usa um XOR-based stream cipher com HMAC como fallback (menos seguro).

def encrypt_message(plaintext: str, conv_password: str = None) -> dict:
    if not plaintext:
        return {"cipher": "", "enc": False}

    if conv_password and CRYPTO_AVAILABLE:
        # Strong encryption with Fernet
        key = base64.urlsafe_b64encode(derive_key_from_passphrase(conv_password))
        f = Fernet(key)
        token = f.encrypt(plaintext.encode('utf-8'))
        return {"cipher": base64.b64encode(token).decode('utf-8'), "enc": True, "method": "fernet"}
    elif conv_password and not CRYPTO_AVAILABLE:
        # Fallback: XOR stream cipher + HMAC-SHA256
        key = derive_key_from_passphrase(conv_password)
        plaintext_bytes = plaintext.encode('utf-8')
        stream = bytes([plaintext_bytes[i] ^ key[i % len(key)] for i in range(len(plaintext_bytes))])
        mac = hmac.new(SERVER_SIDE_SECRET, stream, hashlib.sha256).hexdigest()
        return {"cipher": base64.b64encode(stream).decode('utf-8'), "enc": True, "method": "xor_hmac", "mac": mac}
    else:
        # Not encrypted — but we store an integrity MAC so we can detect tampering
        data = plaintext.encode('utf-8')
        mac = hmac.new(SERVER_SIDE_SECRET, data, hashlib.sha256).hexdigest()
        return {"cipher": base64.b64encode(data).decode('utf-8'), "enc": False, "mac": mac}

def decrypt_message(cipher_obj: dict, conv_password: str = None) -> str:
    if not cipher_obj or "cipher" not in cipher_obj:
        return ""
    try:
        method = cipher_obj.get('method')
        cipher_b64 = cipher_obj['cipher']
        data = base64.b64decode(cipher_b64)

        if cipher_obj.get('enc') and conv_password and method == 'fernet' and CRYPTO_AVAILABLE:
            key = base64.urlsafe_b64encode(derive_key_from_passphrase(conv_password))
            f = Fernet(key)
            return f.decrypt(data).decode('utf-8')
        elif cipher_obj.get('enc') and conv_password and method == 'xor_hmac' and not CRYPTO_AVAILABLE:
            mac = cipher_obj.get('mac')
            calc_mac = hmac.new(SERVER_SIDE_SECRET, data, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(mac or "", calc_mac):
                return "[Mensagem corrompida: MAC inválido]"
            key = derive_key_from_passphrase(conv_password)
            plaintext_bytes = bytes([data[i] ^ key[i % len(key)] for i in range(len(data))])
            return plaintext_bytes.decode('utf-8', errors='replace')
        else:
            # Not encrypted — verify mac
            mac = cipher_obj.get('mac')
            calc_mac = hmac.new(SERVER_SIDE_SECRET, data, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(mac or "", calc_mac):
                return "[Mensagem corrompida: MAC inválido]"
            return data.decode('utf-8', errors='replace')
    except Exception as e:
        return f"[Erro ao decifrar: {e}]"

# ---------------------------
# Firebase helpers (USUÁRIO)
# ---------------------------

def cadastrar_usuario(nome, email, senha):
    try:
        doc_ref = db.collection("Usuarios").document(email)
        if doc_ref.get().exists:
            return False, "E-mail já cadastrado."
        salt, pwd_hash = hash_password(senha)
        doc_ref.set({
            "nome": nome,
            "email": email,
            "senha_hash": pwd_hash,
            "salt": salt,
            "criado_em": datetime.now()
        })
        return True, "Cadastro realizado com sucesso!"
    except Exception as e:
        return False, f"Erro ao cadastrar: {e}"

def login_usuario(email, senha):
    try:
        doc_ref = db.collection("Usuarios").document(email)
        doc = doc_ref.get()
        if doc.exists:
            user = doc.to_dict()
            if verify_password(senha, user.get('salt'), user.get('senha_hash')):
                return True, user.get('nome')
        return False, "E-mail ou senha incorretos."
    except Exception as e:
        return False, f"Erro no login: {e}"

# ---------------------------
# Chats & Mensagens
# ---------------------------

def enviar_mensagem(remetente, destinatario, mensagem_obj):
    # mensagem_obj: dict com campos 'cipher','enc','method',... retornado por encrypt_message
    if not mensagem_obj.get('cipher'):
        return
    db.collection("Chats").document().set({
        "remetente": remetente,
        "destinatario": destinatario,
        "mensagem": mensagem_obj,
        "timestamp": datetime.now()
    })

def ler_mensagens(usuario1, usuario2):
    chats_ref = db.collection("Chats").order_by("timestamp")
    mensagens = []
    for doc in chats_ref.stream():
        data = doc.to_dict()
        if (data["remetente"] == usuario1 and data["destinatario"] == usuario2) or \
           (data["remetente"] == usuario2 and data["destinatario"] == usuario1):
            mensagens.append(data)
    return mensagens

# ---------------------------
# Interface Tkinter (Melhorada)
# ---------------------------

root = tk.Tk()
root.title("Messenger Chat - Melhorado")
root.geometry("900x640")
root.configure(bg="#F3F4F6")

# Variáveis globais
usuario_logado = {"email": None, "nome": None}
current_conv_password = None  # senha opcional para cifrar/desfazer mensagens da conversa atual
selected_contact = None

# Frames principais
left_panel = tk.Frame(root, bg="#FFFFFF", width=280)
left_panel.pack(side="left", fill="y")
main_panel = tk.Frame(root, bg="#F3F4F6")
main_panel.pack(side="right", fill="both", expand=True)

# Left: Perfil + Contatos
profile_frame = tk.Frame(left_panel, bg="#1877F2", height=120)
profile_frame.pack(fill="x")
profile_label = tk.Label(profile_frame, text="Não conectado", fg="white", bg="#1877F2", font=("Arial", 12, "bold"))
profile_label.pack(pady=20, padx=10)
logout_btn = tk.Button(profile_frame, text="Sair", command=lambda: logout(), bg="#ffffff")
logout_btn.pack_forget()

search_var = tk.StringVar()
search_entry = tk.Entry(left_panel, textvariable=search_var)
search_entry.pack(padx=10, pady=8, fill="x")

contacts_listbox = tk.Listbox(left_panel)
contacts_listbox.pack(padx=10, pady=4, fill="both", expand=True)

new_conv_btn = tk.Button(left_panel, text="Abrir conversa", command=lambda: open_selected_contact())
new_conv_btn.pack(padx=10, pady=6, fill="x")

# Main panel: top bar + messages + composer
top_bar = tk.Frame(main_panel, bg="#FFFFFF", height=60)
top_bar.pack(fill="x")
conv_label = tk.Label(top_bar, text="Nenhuma conversa aberta", font=("Arial", 14, "bold"), bg="#FFFFFF")
conv_label.pack(side="left", padx=10)
set_conv_pass_btn = tk.Button(top_bar, text="Senha da conversa", command=lambda: set_conv_password())
set_conv_pass_btn.pack(side="right", padx=10)

messages_area = scrolledtext.ScrolledText(main_panel, wrap=tk.WORD, state="disabled", font=("Arial", 12))
messages_area.pack(padx=10, pady=10, fill="both", expand=True)

composer_frame = tk.Frame(main_panel, bg="#F3F4F6")
composer_frame.pack(fill="x", padx=10, pady=8)
msg_entry = tk.Entry(composer_frame, font=("Arial", 12))
msg_entry.pack(side="left", fill="x", expand=True, padx=(0,8))
attach_btn = tk.Button(composer_frame, text="Anexar", command=lambda: attach_file())
attach_btn.pack(side="left", padx=4)
send_btn = tk.Button(composer_frame, text="Enviar", bg="#1877F2", fg="white", command=lambda: send_current_message())
send_btn.pack(side="right")

# ---------------------------
# UI Functions
# ---------------------------

def refresh_contacts():
    contacts_listbox.delete(0, tk.END)
    try:
        users = db.collection('Usuarios').stream()
        query = search_var.get().lower()
        for doc in users:
            u = doc.to_dict()
            email = u.get('email')
            nome = u.get('nome')
            if usuario_logado['email'] and email == usuario_logado['email']:
                continue
            if query and query not in nome.lower() and query not in email.lower():
                continue
            contacts_listbox.insert(tk.END, f"{nome} <{email}>")
    except Exception as e:
        print('Erro ao buscar contatos:', e)

search_var.trace_add('write', lambda *args: refresh_contacts())

def open_selected_contact():
    global selected_contact, current_conv_password
    sel = contacts_listbox.curselection()
    if not sel:
        messagebox.showinfo('Info', 'Selecione um contato na lista')
        return
    text = contacts_listbox.get(sel[0])
    # Expected format: Nome <email>
    if '<' in text and '>' in text:
        email = text.split('<')[1].split('>')[0]
        selected_contact = email
        conv_label.config(text=f"Conversando com {text.split('<')[0].strip()}")
        current_conv_password = None
        messages_area.config(state='normal')
        messages_area.delete(1.0, tk.END)
        messages_area.config(state='disabled')
        load_messages()


def set_conv_password():
    global current_conv_password
    if not selected_contact:
        messagebox.showinfo('Info', 'Abra uma conversa primeiro')
        return
    pw = simple_input('Digite a senha de conversa (deixe em branco para desativar):')
    current_conv_password = pw if pw else None
    if current_conv_password and not CRYPTO_AVAILABLE:
        messagebox.showwarning('Aviso', 'Criptografia forte não está disponível (biblioteca cryptography não instalada). Usando método fallback menos seguro.')
    load_messages()

attached_file = None

def attach_file():
    global attached_file
    path = filedialog.askopenfilename()
    if not path:
        return
    try:
        with open(path, 'rb') as f:
            data = f.read()
        attached_file = {'filename': path.split('/')[-1], 'data': base64.b64encode(data).decode('utf-8')}
        messagebox.showinfo('Anexo', f"Arquivo {attached_file['filename']} pronto para envio")
    except Exception as e:
        messagebox.showerror('Erro anexo', str(e))


def send_current_message():
    global attached_file
    if not usuario_logado['email'] or not selected_contact:
        messagebox.showinfo('Info', 'Você precisa estar logado e ter uma conversa aberta')
        return
    text = msg_entry.get().strip()
    if not text and not attached_file:
        return
    payload = {'text': text, 'attachment': attached_file}
    json_payload = json.dumps(payload, ensure_ascii=False)
    cipher_obj = encrypt_message(json_payload, current_conv_password)
    enviar_mensagem(usuario_logado['email'], selected_contact, cipher_obj)
    msg_entry.delete(0, tk.END)
    attached_file = None
    load_messages()


def format_message_display(data):
    remetente = data['remetente']
    ts = data['timestamp']
    if isinstance(ts, datetime):
        ts_str = ts.strftime('%Y-%m-%d %H:%M:%S')
    else:
        try:
            ts_str = ts.ToDatetime().strftime('%Y-%m-%d %H:%M:%S')
        except Exception:
            ts_str = str(ts)

    mensagem = decrypt_message(data.get('mensagem'), current_conv_password)
    try:
        payload = json.loads(mensagem)
        text = payload.get('text', '')
        attachment = payload.get('attachment')
    except Exception:
        text = mensagem
        attachment = None

    prefix = 'Você' if remetente == usuario_logado['email'] else remetente
    display = f"[{ts_str}] {prefix}: {text}"
    if attachment:
        display += f" [Anexo: {attachment.get('filename')}]"
    return display


def load_messages():
    messages_area.config(state='normal')
    messages_area.delete(1.0, tk.END)
    if not selected_contact:
        messages_area.insert(tk.END, 'Nenhuma conversa aberta')
        messages_area.config(state='disabled')
        return
    msgs = ler_mensagens(usuario_logado['email'], selected_contact)
    for m in msgs:
        messages_area.insert(tk.END, format_message_display(m) + '\n\n')
    messages_area.config(state='disabled')
    messages_area.see(tk.END)

# ---------------------------
# Login / Registro Simplificados (pop-up windows)
# ---------------------------

def simple_input(prompt):
    value = None
    win = tk.Toplevel(root)
    win.title('Entrada')
    tk.Label(win, text=prompt).pack(padx=10, pady=8)
    entry = tk.Entry(win, width=40)
    entry.pack(padx=10, pady=4)
    def confirmar():
        nonlocal value
        value = entry.get()
        win.destroy()
    tk.Button(win, text='OK', command=confirmar).pack(pady=8)
    win.grab_set()
    root.wait_window(win)
    return value


def show_login():
    win = tk.Toplevel(root)
    win.title('Login')
    win.geometry('380x260')

    tk.Label(win, text='E-mail:').pack(padx=10, pady=4)
    email_e = tk.Entry(win)
    email_e.pack(padx=10)
    tk.Label(win, text='Senha:').pack(padx=10, pady=4)
    senha_e = tk.Entry(win, show='*')
    senha_e.pack(padx=10)
    status = tk.Label(win, text='')
    status.pack(pady=6)

    def tentar():
        email = email_e.get().strip()
        senha = senha_e.get().strip()
        if not email or not senha:
            status.config(text='Preencha todos os campos', fg='red')
            return
        ok, resp = login_usuario(email, senha)
        if ok:
            usuario_logado['email'] = email
            usuario_logado['nome'] = resp
            profile_label.config(text=f"{resp} <{email}>")
            logout_btn.pack()
            refresh_contacts()
            win.destroy()
        else:
            status.config(text=resp, fg='red')

    tk.Button(win, text='Entrar', command=tentar, bg='#1877F2', fg='white').pack(pady=8)
    tk.Button(win, text='Criar conta', command=lambda: (win.destroy(), show_register())).pack()
    win.grab_set()


def show_register():
    win = tk.Toplevel(root)
    win.title('Criar Conta')
    win.geometry('380x340')

    tk.Label(win, text='Nome completo:').pack(padx=10, pady=4)
    nome_e = tk.Entry(win)
    nome_e.pack(padx=10)
    tk.Label(win, text='E-mail:').pack(padx=10, pady=4)
    email_e = tk.Entry(win)
    email_e.pack(padx=10)
    tk.Label(win, text='Senha:').pack(padx=10, pady=4)
    senha_e = tk.Entry(win, show='*')
    senha_e.pack(padx=10)
    status = tk.Label(win, text='')
    status.pack(pady=6)

    def criar():
        nome = nome_e.get().strip()
        email = email_e.get().strip()
        senha = senha_e.get().strip()
        if not nome or not email or not senha:
            status.config(text='Preencha todos os campos', fg='red')
            return
        ok, msg = cadastrar_usuario(nome, email, senha)
        if ok:
            messagebox.showinfo('Sucesso', msg)
            win.destroy()
            show_login()
        else:
            status.config(text=msg, fg='red')

    tk.Button(win, text='Cadastrar', command=criar, bg='#42B72A', fg='white').pack(pady=8)
    win.grab_set()


def logout():
    usuario_logado['email'] = None
    usuario_logado['nome'] = None
    profile_label.config(text='Não conectado')
    logout_btn.pack_forget()
    contacts_listbox.delete(0, tk.END)
    conv_label.config(text='Nenhuma conversa aberta')
    messages_area.config(state='normal')
    messages_area.delete(1.0, tk.END)
    messages_area.insert(tk.END, 'Faça login para começar a conversar')
    messages_area.config(state='disabled')

# ---------------------------
# Inicialização UI
# ---------------------------

messages_area.config(state='normal')
messages_area.delete(1.0, tk.END)
messages_area.insert(tk.END, 'Faça login para começar a conversar')
messages_area.config(state='disabled')

refresh_contacts()

# Expose quick login/register buttons
bottom_panel = tk.Frame(left_panel, bg='#FFFFFF')
bottom_panel.pack(fill='x')
btn_login = tk.Button(bottom_panel, text='Login', command=show_login)
btn_login.pack(side='left', padx=10, pady=8)
btn_register = tk.Button(bottom_panel, text='Criar Conta', command=show_register)
btn_register.pack(side='right', padx=10, pady=8)

# Auto-refresh messages every 3.5 seconds if a conversation is open

def periodic_refresh():
    if usuario_logado['email'] and selected_contact:
        load_messages()
    root.after(3500, periodic_refresh)

root.after(3500, periodic_refresh)

root.mainloop()
